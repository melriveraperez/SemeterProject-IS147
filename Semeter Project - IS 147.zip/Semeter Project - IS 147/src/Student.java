public class Student {
    private String name;
    private String goal;

    // Constructor
    public Student(String name, String goal) {
        this.name = name;
        this.goal = goal;
    }

    // Getter and Setter methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    // Display student info
    public void displayStudentInfo() {
        System.out.println("Student Name: " + name);
        System.out.println("Goal: " + goal);
    }
}
