import java.util.ArrayList;
import java.util.Scanner;

import java.util.Date;
import java.util.Random;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Student student = new Student("John Doe", "Finish the semester strong!");
        TaskManager taskManager = new TaskManager();

        // Display student info
        student.displayStudentInfo();

        // Main menu loop
        boolean exit = false;
        while (!exit) {
            System.out.println("\nStudent Time Management Tool");
            System.out.println("1. Add Task");
            System.out.println("2. Show Task List");
            System.out.println("3. Set Goal");
            System.out.println("4. Send Reminder");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter task description: ");
                    String task = scanner.nextLine();
                    taskManager.scheduleTask(task);
                    break;
                case 2:
                    taskManager.showTaskList();
                    break;
                case 3:
                    System.out.print("Enter goal: ");
                    String goal = scanner.nextLine();
                    taskManager.setGoal(goal);
                    break;
                case 4:
                    taskManager.sendReminder();
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option! Please try again.");
                    break;
            }
        }

        scanner.close();
    }
}
