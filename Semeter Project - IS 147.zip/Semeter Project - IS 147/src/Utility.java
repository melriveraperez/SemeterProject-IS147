import java.util.Date;
import java.util.Random;

public class Utility {

    // Method to get the current date
    public static String getCurrentDate() {
        Date date = new Date();
        return date.toString();
    }

    // Method to generate a random task ID
    public static int generateRandomID() {
        Random rand = new Random();
        return rand.nextInt(1000);  // Generate a random ID between 0 and 999
    }

    // Method to display a message
    public static void displayMessage(String message) {
        System.out.println(message);
    }

    // Method to calculate the remaining time (example)
    public static String calculateTimeLeft(int currentTime, int totalTime) {
        return "Remaining Time: " + (totalTime - currentTime) + " hours";
    }
}
