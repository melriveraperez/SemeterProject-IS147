import java.util.ArrayList;

public class TaskManager {
    private ArrayList<String> tasks = new ArrayList<>();

    // Method to add a task
    public void scheduleTask(String task) {
        tasks.add(task);
    }

    // Method to show all tasks
    public void showTaskList() {
        System.out.println("Scheduled Tasks:");
        for (String task : tasks) {
            System.out.println("- " + task);
        }
    }

    // Method to send reminder (print statement)
    public void sendReminder() {
        System.out.println("Reminder: Don't forget to complete your tasks!");
    }

    // Method to set a goal
    public void setGoal(String goal) {
        System.out.println("Goal set: " + goal);
    }
}
